## Datasets released used in the paper

#### Systematic Generalization

- `data_089907f8` - Train: k=2,3, Test: k=2,3,4,5,6,7,8,9,10
- `data_db9b8f04` - Train: k=2,3,4 Test: k=2,3,4,5,6,7,8,9,10

#### Robust Reasoning

- `data_7c5b0e70` - Train: k=1.2,1.3, Test: 1.2,1.3,2.3,3.3,4.3
- `data_06b8f2a1` - Train: k=2.2,2.3, Test: 2.2,2.3,1.3,3.3,4.3
- `data_523348e6` - Train: k=3.2,3.3, Test: 3.2,3.3,1.3,2.3,4.3
- `data_d83ecc3e` - Train: k=4.2,4.3, Test: 4.2,4.3,1.3,2.3,3.3


